<?php
defined('ABSPATH') || exit;

final class LDVA_Scanner {
    public static function is_supported_video_url(string $url): bool {
        $host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));
        return strpos($host, 'youtu.be') !== false
            || strpos($host, 'youtube.com') !== false
            || strpos($host, 'youtube-nocookie.com') !== false
            || strpos($host, 'vimeo.com') !== false
            || strpos($host, 'player.mediadelivery.net') !== false
            || strpos($host, 'iframe.mediadelivery.net') !== false
            || $host === 'dash.bunny.net';
    }

    public static function contains_supported_video(string $html): bool {
        if (!preg_match('~<iframe\b[^>]*\bsrc\s*=\s*(["\'])(.*?)\1~is', $html, $match)) {
            return false;
        }
        return self::is_supported_video_url(html_entity_decode($match[2], ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    }

    public static function is_bunny_url(string $url): bool {
        $host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));
        return $host === 'player.mediadelivery.net' || $host === 'iframe.mediadelivery.net' || $host === 'dash.bunny.net';
    }

    /**
     * Claves canónicas ("biblioteca/id") de los videos Bunny que se muestran
     * realmente en la lección. Es el espejo de lo que se renderiza en el frontend
     * (contenido + iframe administrado + shortcode administrado). Se usa para la
     * validación server-side de la progresión, por lo que solo debe incluir los
     * videos efectivamente visibles: sobre-incluir bloquearía la lección de forma
     * permanente.
     */
    public static function bunny_video_keys(int $lesson_id): array {
        $post = get_post($lesson_id);
        if (!$post || $post->post_type !== 'sfwd-lessons') {
            return [];
        }

        $chunks = [$post->post_content];
        $embed_meta = (string) get_post_meta($lesson_id, '_ldva_video_embed', true);
        if ($embed_meta !== '') {
            $chunks[] = $embed_meta;
        }
        $shortcode_meta = (string) get_post_meta($lesson_id, '_ldva_video_shortcode', true);
        if ($shortcode_meta !== '') {
            $chunks[] = $shortcode_meta;
        }

        $keys = [];
        foreach ($chunks as $chunk) {
            $chunk = (string) $chunk;
            self::collect_bunny_keys($chunk, $keys);
            // Expandir shortcodes solo cuando pueden generar un iframe Bunny,
            // para no ejecutar do_shortcode sobre contenido pesado innecesariamente.
            if (strpos($chunk, 'bunnycdn_stream_video') !== false) {
                self::collect_bunny_keys(do_shortcode(shortcode_unautop($chunk)), $keys);
            }
        }

        return array_values(array_unique($keys));
    }

    private static function collect_bunny_keys(string $html, array &$keys): void {
        if ($html === '') {
            return;
        }
        $decoded = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if (preg_match_all('~(?:player|iframe)\.mediadelivery\.net/embed/(\d+)/([a-f0-9-]{20,})~i', $decoded, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $keys[] = $match[1] . '/' . strtolower($match[2]);
            }
        }
        if (preg_match_all('~dash\.bunny\.net/stream/(\d+)/[^\s"\'<>]*[?&]vid=([a-f0-9-]{20,})~i', $decoded, $dash, PREG_SET_ORDER)) {
            foreach ($dash as $match) {
                $keys[] = $match[1] . '/' . strtolower($match[2]);
            }
        }
    }

    /**
     * Normaliza una clave de progresión reportada por el navegador al formato
     * canónico "biblioteca/id" en minúsculas, o cadena vacía si no es válida.
     */
    public static function normalize_bunny_key(string $key): string {
        if (preg_match('~^(\d+)/([a-f0-9-]{20,})$~i', trim($key), $match)) {
            return $match[1] . '/' . strtolower($match[2]);
        }
        return '';
    }

    public static function courses(): array {
        return get_posts([
            'post_type' => 'sfwd-courses',
            'post_status' => ['publish', 'draft', 'private', 'pending'],
            'numberposts' => -1,
            'orderby' => 'title',
            'order' => 'ASC',
        ]);
    }

    public static function lessons(int $course_id): array {
        $ids = [];

        if (function_exists('learndash_course_get_steps_by_type')) {
            $ids = (array) learndash_course_get_steps_by_type($course_id, 'sfwd-lessons');
        } elseif (function_exists('learndash_get_course_steps')) {
            $steps = (array) learndash_get_course_steps($course_id);
            foreach ($steps as $step_id) {
                if (get_post_type($step_id) === 'sfwd-lessons') {
                    $ids[] = (int) $step_id;
                }
            }
        }

        if (!$ids) {
            $candidates = get_posts([
                'post_type' => 'sfwd-lessons',
                'post_status' => ['publish', 'draft', 'private', 'pending'],
                'numberposts' => -1,
                'fields' => 'ids',
                'orderby' => 'menu_order title',
                'order' => 'ASC',
            ]);
            foreach ($candidates as $lesson_id) {
                if (self::belongs_to_course((int) $lesson_id, $course_id)) {
                    $ids[] = (int) $lesson_id;
                }
            }
        }

        $ids = array_values(array_unique(array_map('intval', $ids)));
        return $ids ? get_posts([
            'post_type' => 'sfwd-lessons',
            'post__in' => $ids,
            'post_status' => ['publish', 'draft', 'private', 'pending'],
            'numberposts' => -1,
            'orderby' => 'post__in',
        ]) : [];
    }

    private static function belongs_to_course(int $lesson_id, int $course_id): bool {
        $direct = (int) get_post_meta($lesson_id, 'course_id', true);
        if ($direct === $course_id) {
            return true;
        }
        $settings = get_post_meta($lesson_id, '_sfwd-lessons', true);
        if (is_array($settings)) {
            foreach (['sfwd-lessons_course', 'course_id'] as $key) {
                if (isset($settings[$key]) && (int) $settings[$key] === $course_id) {
                    return true;
                }
            }
        }
        if (function_exists('learndash_get_course_id')) {
            return (int) learndash_get_course_id($lesson_id) === $course_id;
        }
        return false;
    }

    public static function scan_course(int $course_id): array {
        $course = get_post($course_id);
        if (!$course || $course->post_type !== 'sfwd-courses') {
            return [];
        }

        $rows = [];
        foreach (self::lessons($course_id) as $lesson) {
            $videos = self::scan_lesson($lesson);
            if (!$videos) {
                $rows[] = self::row($course, $lesson, '', '', '', '', 'No encontrado');
                continue;
            }
            foreach ($videos as $video) {
                $rows[] = self::row(
                    $course,
                    $lesson,
                    $video['platform'],
                    $video['url'],
                    $video['embed'],
                    $video['shortcode'] ?? '',
                    'Encontrado'
                );
            }
        }
        return $rows;
    }

    private static function row(WP_Post $course, WP_Post $lesson, string $platform, string $url, string $embed, string $shortcode, string $status): array {
        return [
            'course' => html_entity_decode(get_the_title($course), ENT_QUOTES | ENT_HTML5, 'UTF-8'),
            'course_id' => $course->ID,
            'lesson' => html_entity_decode(get_the_title($lesson), ENT_QUOTES | ENT_HTML5, 'UTF-8'),
            'lesson_id' => $lesson->ID,
            'lesson_url' => self::lesson_url($lesson->ID, $course->ID),
            'platform' => $platform,
            'url' => $url,
            'embed' => $embed,
            'shortcode' => $shortcode,
            'status' => $status,
            'edit_url' => self::editable_url($lesson->ID, $url),
            'edit_embed' => (string) get_post_meta($lesson->ID, '_ldva_video_embed', true),
            'edit_shortcode' => (string) get_post_meta($lesson->ID, '_ldva_video_shortcode', true),
        ];
    }

    private static function lesson_url(int $lesson_id, int $course_id): string {
        if (function_exists('learndash_get_step_permalink')) {
            $url = learndash_get_step_permalink($lesson_id, $course_id);
            if ($url) {
                return esc_url_raw($url);
            }
        }
        return esc_url_raw(get_permalink($lesson_id));
    }

    private static function editable_url(int $lesson_id, string $detected_url): string {
        $custom = (string) get_post_meta($lesson_id, '_ldva_video_url', true);
        if ($custom !== '') {
            return $custom;
        }
        $settings = get_post_meta($lesson_id, '_sfwd-lessons', true);
        if (is_array($settings) && !empty($settings['sfwd-lessons_lesson_video_url'])) {
            return (string) $settings['sfwd-lessons_lesson_video_url'];
        }
        return $detected_url;
    }

    private static function scan_lesson(WP_Post $lesson): array {
        $sources = [$lesson->post_content];
        $meta = get_post_meta($lesson->ID);
        foreach ($meta as $meta_key => $values) {
            if ($meta_key === '_ldva_video_shortcode') continue;
            foreach ((array) $values as $value) {
                self::flatten_value(maybe_unserialize($value), $sources);
            }
        }

        $found = [];
        foreach ($sources as $source) {
            self::extract_from_text((string) $source, $found);
        }
        $shortcode = (string) get_post_meta($lesson->ID, '_ldva_video_shortcode', true);
        if ($shortcode !== '') {
            $shortcode_found = [];
            self::extract_from_text($shortcode, $shortcode_found);
            self::extract_from_text(do_shortcode($shortcode), $shortcode_found);
            foreach ($shortcode_found as $key => $video) {
                $video['shortcode'] = $shortcode;
                if (isset($found[$key])) {
                    if ($found[$key]['embed'] === '' && $video['embed'] !== '') $found[$key]['embed'] = $video['embed'];
                    $found[$key]['shortcode'] = $shortcode;
                } else {
                    $found[$key] = $video;
                }
            }
        }
        return array_values($found);
    }

    private static function flatten_value($value, array &$sources): void {
        if (is_string($value)) {
            $sources[] = $value;
        } elseif (is_array($value) || is_object($value)) {
            foreach ((array) $value as $nested) {
                self::flatten_value($nested, $sources);
            }
        }
    }

    private static function extract_from_text(string $text, array &$found): void {
        if ($text === '') {
            return;
        }
        $decoded = html_entity_decode(wp_unslash($text), ENT_QUOTES | ENT_HTML5, 'UTF-8');

        if (preg_match_all('~<iframe\b[^>]*\bsrc\s*=\s*(["\'])(.*?)\1[^>]*>(?:\s*</iframe>)?~is', $decoded, $iframes, PREG_SET_ORDER)) {
            foreach ($iframes as $iframe) {
                self::add_video($iframe[2], $iframe[0], $found);
            }
        }

        if (preg_match_all('~https?://[^\s<>"\'\]\)]+~i', $decoded, $urls)) {
            foreach ($urls[0] as $url) {
                self::add_video(rtrim($url, '.,;'), '', $found);
            }
        }
    }

    private static function add_video(string $url, string $embed, array &$found): void {
        $url = esc_url_raw(trim($url));
        if (!$url) {
            return;
        }
        $host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));
        if (strpos($host, 'youtu.be') !== false || strpos($host, 'youtube.com') !== false || strpos($host, 'youtube-nocookie.com') !== false) {
            $platform = 'YouTube';
        } elseif (strpos($host, 'vimeo.com') !== false) {
            $platform = 'Vimeo';
        } elseif (strpos($host, 'player.mediadelivery.net') !== false || strpos($host, 'iframe.mediadelivery.net') !== false) {
            $platform = 'Bunny Stream';
        } elseif ($host === 'dash.bunny.net') {
            $platform = 'Bunny Stream';
        } else {
            return;
        }

        $key = self::video_key($url, $platform);
        if (!preg_match('/^(youtube|vimeo|bunny stream):/i', $key)) {
            return;
        }
        if (!isset($found[$key])) {
            $found[$key] = [
                'platform' => $platform,
                'url' => $url,
                'embed' => $embed ? wp_kses($embed, [
                    'iframe' => [
                        'src' => true, 'width' => true, 'height' => true, 'title' => true,
                        'frameborder' => true, 'allow' => true, 'allowfullscreen' => true,
                        'loading' => true, 'referrerpolicy' => true, 'class' => true,
                    ],
                ]) : '',
                'shortcode' => '',
            ];
            return;
        }

        if ($embed !== '' && $found[$key]['embed'] === '') {
            $found[$key]['embed'] = wp_kses($embed, [
                'iframe' => [
                    'src' => true, 'width' => true, 'height' => true, 'title' => true,
                    'frameborder' => true, 'allow' => true, 'allowfullscreen' => true,
                    'loading' => true, 'referrerpolicy' => true, 'class' => true,
                ],
            ]);
        }
        if (self::is_preferred_original_url($url, $platform) && !self::is_preferred_original_url($found[$key]['url'], $platform)) {
            $found[$key]['url'] = $url;
        }
    }

    public static function video_key(string $url, string $platform = ''): string {
        if ($platform === '') {
            $host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));
            if (strpos($host, 'youtu') !== false) $platform = 'YouTube';
            if (strpos($host, 'vimeo') !== false) $platform = 'Vimeo';
            if (strpos($host, 'mediadelivery.net') !== false) $platform = 'Bunny Stream';
            if ($host === 'dash.bunny.net') $platform = 'Bunny Stream';
        }
        $parts = wp_parse_url($url);
        $host = strtolower((string) ($parts['host'] ?? ''));
        $path = trim((string) ($parts['path'] ?? ''), '/');
        $id = '';

        if ($platform === 'YouTube') {
            if (strpos($host, 'youtu.be') !== false) {
                $id = explode('/', $path)[0] ?? '';
            } elseif (preg_match('~(?:embed/|shorts/|live/)([A-Za-z0-9_-]{6,})~', $path, $match)) {
                $id = $match[1];
            } elseif (!empty($parts['query'])) {
                parse_str($parts['query'], $query);
                $id = sanitize_text_field($query['v'] ?? '');
            }
        } elseif ($platform === 'Vimeo' && preg_match('~(?:video/)?(\d{6,})~', $path, $match)) {
            $id = $match[1];
        } elseif ($platform === 'Bunny Stream' && preg_match('~embed/(\d+)/([a-f0-9-]{20,})~i', $path, $match)) {
            $id = $match[1] . '/' . strtolower($match[2]);
        } elseif ($platform === 'Bunny Stream' && $host === 'dash.bunny.net' && preg_match('~stream/(\d+)/~i', $path, $match)) {
            parse_str((string) ($parts['query'] ?? ''), $query);
            $video_id = sanitize_text_field($query['vid'] ?? '');
            if (preg_match('/^[a-f0-9-]{20,}$/i', $video_id)) {
                $id = $match[1] . '/' . strtolower($video_id);
            }
        }

        return $id !== '' ? strtolower($platform) . ':' . strtolower($id) : strtolower($url);
    }

    private static function is_preferred_original_url(string $url, string $platform): bool {
        $host = strtolower((string) wp_parse_url($url, PHP_URL_HOST));
        if ($platform === 'Vimeo') {
            return $host === 'vimeo.com' || $host === 'www.vimeo.com';
        }
        if ($platform === 'Bunny Stream') {
            return strpos($host, 'player.mediadelivery.net') !== false || $host === 'dash.bunny.net';
        }
        return strpos($host, 'youtu.be') !== false || strpos($url, 'watch?') !== false;
    }
}
