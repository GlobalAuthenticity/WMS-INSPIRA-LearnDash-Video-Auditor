(() => {
  'use strict';

  const bunnySelector = [
    'iframe[src*="player.mediadelivery.net"]',
    'iframe[src*="iframe.mediadelivery.net"]'
  ].join(',');
  const buttonSelectors = [
    '.learndash_mark_complete_button input[type="submit"]',
    'input.learndash_mark_complete_button',
    'button.learndash_mark_complete_button',
    '.learndash-wrapper form.sfwd-mark-complete input[type="submit"]',
    '.learndash-wrapper form.sfwd-mark-complete button'
  ].join(',');

  function completionControls() {
    const controls = [...document.querySelectorAll(buttonSelectors)];
    document.querySelectorAll('button, input[type="submit"], a').forEach((element) => {
      const text = (element.value || element.textContent || '').trim().toLocaleLowerCase();
      if ((text.includes('marcar completado') || text.includes('mark complete')) && !controls.includes(element)) {
        controls.push(element);
      }
    });
    return controls;
  }

  // Clave canónica "biblioteca/id" en minúsculas, igual que la del servidor.
  function videoKey(iframe) {
    try {
      const url = new URL(iframe.src);
      const match = url.pathname.match(/embed\/(\d+)\/([a-f0-9-]{20,})/i);
      return match ? `${match[1]}/${match[2].toLowerCase()}` : '';
    } catch (_) {
      return '';
    }
  }

  function setLocked(controls, locked) {
    controls.forEach((control) => {
      control.classList.toggle('ldva-completion-locked', locked);
      control.setAttribute('aria-disabled', locked ? 'true' : 'false');
      if ('disabled' in control) control.disabled = locked;
      if (locked) control.setAttribute('tabindex', '-1');
      else control.removeAttribute('tabindex');
    });
  }

  async function report(key) {
    const body = new URLSearchParams({
      action: 'ldva_mark_video_watched',
      nonce: LDVABunny.nonce,
      lesson_id: LDVABunny.lessonId,
      video_key: key
    });
    const response = await fetch(LDVABunny.ajaxUrl, {
      method: 'POST',
      credentials: 'same-origin',
      headers: {'Content-Type': 'application/x-www-form-urlencoded'},
      body
    });
    const data = await response.json();
    if (!data || !data.success) {
      throw new Error((data && data.data && data.data.message) || 'report_failed');
    }
    return data.data;
  }

  function init() {
    const iframeMap = new Map();
    document.querySelectorAll(bunnySelector).forEach((iframe) => {
      const key = videoKey(iframe);
      if (key && !iframeMap.has(key)) iframeMap.set(key, iframe);
    });
    const videos = [...iframeMap.entries()];
    if (!videos.length) return;

    const controls = completionControls();
    if (!controls.length) return;

    // Fuente de verdad: lo que el servidor ya tiene registrado para este usuario.
    const completed = new Set((LDVABunny.watched || []).map((k) => String(k).toLowerCase()));

    const notice = document.createElement('div');
    notice.className = 'ldva-progression-notice';
    const lastIframe = videos[videos.length - 1][1];
    const anchor = lastIframe.closest('.ldva-lesson-video') || lastIframe.parentElement || lastIframe;
    anchor.insertAdjacentElement('afterend', notice);

    const refresh = (message, tone) => {
      const allCompleted = completed.size >= videos.length;
      setLocked(controls, !allCompleted);
      notice.textContent = message || (allCompleted ? LDVABunny.readyText : LDVABunny.waitingText);
      notice.classList.toggle('is-ready', allCompleted && !message);
      notice.classList.toggle('is-error', tone === 'error');
      notice.hidden = false;
    };
    refresh();

    if (!window.playerjs || !window.playerjs.Player) {
      // Sin el reproductor no hay señal de finalización. El botón permanece
      // bloqueado (el servidor también lo exige); se puede desactivar la barrera
      // con el filtro PHP ldva_enforce_bunny_progression si fuese necesario.
      return;
    }

    videos.forEach(([key, iframe]) => {
      if (completed.has(key)) return;
      try {
        const player = new window.playerjs.Player(iframe);
        player.on('ended', async () => {
          try {
            await report(key);
            completed.add(key);
            refresh();
          } catch (_) {
            refresh(LDVABunny.errorText, 'error');
          }
        });
      } catch (_) {
        /* Si un iframe no expone la API, los demás siguen contando. */
      }
    });

    document.addEventListener('click', (event) => {
      const locked = event.target.closest('.ldva-completion-locked');
      if (locked) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
    }, true);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
