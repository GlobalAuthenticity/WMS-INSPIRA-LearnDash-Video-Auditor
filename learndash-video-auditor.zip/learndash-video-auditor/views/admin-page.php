<?php defined('ABSPATH') || exit; ?>
<div class="ldva-app">
    <div class="wrap ldva-wrap">
        <header class="ldva-header">
            <div class="ldva-header-text">
                <h1 class="ldva-title">
                    <span class="ldva-title-icon dashicons dashicons-video-alt3" aria-hidden="true"></span>
                    <?php esc_html_e('Auditor de videos de cursos', 'ld-video-auditor'); ?>
                </h1>
                <p class="ldva-subtitle"><?php esc_html_e('Localiza videos de YouTube, Vimeo y Bunny Stream en el contenido y la configuración de las lecciones.', 'ld-video-auditor'); ?></p>
            </div>
            <div class="ldva-toolbar" role="group" aria-label="<?php esc_attr_e('Exportar resultados', 'ld-video-auditor'); ?>">
                <button type="button" class="button" data-export="csv">
                    <span class="dashicons dashicons-media-spreadsheet" aria-hidden="true"></span>
                    <?php esc_html_e('Exportar CSV', 'ld-video-auditor'); ?>
                </button>
                <button type="button" class="button" data-export="xlsx">
                    <span class="dashicons dashicons-media-spreadsheet" aria-hidden="true"></span>
                    <?php esc_html_e('Exportar Excel', 'ld-video-auditor'); ?>
                </button>
                <button type="button" class="button button-primary" data-export="xlsx" data-scope="all">
                    <span class="dashicons dashicons-download" aria-hidden="true"></span>
                    <?php esc_html_e('Excel de todos los cursos', 'ld-video-auditor'); ?>
                </button>
            </div>
        </header>

        <?php if (!post_type_exists('sfwd-courses')) : ?>
            <div class="notice notice-warning inline ldva-notice">
                <p><?php esc_html_e('LearnDash no está activo. Active LearnDash para consultar los cursos.', 'ld-video-auditor'); ?></p>
            </div>
        <?php endif; ?>

        <section class="ldva-card ldva-token-card" aria-label="<?php esc_attr_e('Autenticación por token de Bunny Stream', 'ld-video-auditor'); ?>">
            <div class="ldva-token-header">
                <div>
                    <h2 class="ldva-token-title"><?php esc_html_e('Autenticación por token (Bunny Stream)', 'ld-video-auditor'); ?></h2>
                    <p class="description">
                        <?php esc_html_e('Si una biblioteca de Bunny tiene activada "Embed View Token Authentication", los videos no reproducen sin firmar el iframe. Agregue el ID de la biblioteca y su clave de token (Bunny: Stream > Video Library > Security > Embed View Token Authentication Key) para que el plugin firme automáticamente todos los embeds generados de esa biblioteca. El token se recalcula en cada carga de página, así que "No expira" solo fija una fecha de vencimiento muy lejana (10 años) para esa firma; Bunny exige siempre una fecha de expiración, no admite tokens verdaderamente permanentes.', 'ld-video-auditor'); ?>
                    </p>
                </div>
            </div>
            <div id="ldva-token-rows" class="ldva-token-rows"></div>
            <div class="ldva-token-actions">
                <button type="button" class="button" id="ldva-token-add">
                    <span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>
                    <?php esc_html_e('Añadir biblioteca', 'ld-video-auditor'); ?>
                </button>
                <button type="button" class="button button-primary" id="ldva-token-save">
                    <span class="dashicons dashicons-saved" aria-hidden="true"></span>
                    <?php esc_html_e('Guardar tokens', 'ld-video-auditor'); ?>
                </button>
                <span id="ldva-token-message" class="ldva-modal-message" aria-live="polite"></span>
            </div>
        </section>

        <section class="ldva-card ldva-filters" aria-label="<?php esc_attr_e('Filtros', 'ld-video-auditor'); ?>">
            <div class="ldva-field">
                <label for="ldva-course"><?php esc_html_e('Curso', 'ld-video-auditor'); ?></label>
                <select id="ldva-course">
                    <option value=""><?php esc_html_e('Seleccione un curso', 'ld-video-auditor'); ?></option>
                    <?php foreach ($courses as $course) : ?>
                        <option value="<?php echo esc_attr($course->ID); ?>"><?php echo esc_html(get_the_title($course)); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="ldva-field ldva-field-search">
                <label for="ldva-search"><?php esc_html_e('Buscar', 'ld-video-auditor'); ?></label>
                <div class="ldva-search-input">
                    <span class="dashicons dashicons-search" aria-hidden="true"></span>
                    <input id="ldva-search" type="search" placeholder="<?php esc_attr_e('Curso, lección o URL…', 'ld-video-auditor'); ?>">
                </div>
            </div>
            <div class="ldva-field">
                <label for="ldva-platform"><?php esc_html_e('Plataforma', 'ld-video-auditor'); ?></label>
                <select id="ldva-platform">
                    <option value=""><?php esc_html_e('Todas', 'ld-video-auditor'); ?></option>
                    <option>YouTube</option>
                    <option>Vimeo</option>
                    <option>Bunny Stream</option>
                </select>
            </div>
            <div class="ldva-field">
                <label for="ldva-status"><?php esc_html_e('Estado', 'ld-video-auditor'); ?></label>
                <select id="ldva-status">
                    <option value=""><?php esc_html_e('Todos', 'ld-video-auditor'); ?></option>
                    <option><?php esc_html_e('Encontrado', 'ld-video-auditor'); ?></option>
                    <option><?php esc_html_e('No encontrado', 'ld-video-auditor'); ?></option>
                </select>
            </div>
        </section>

        <section class="ldva-card ldva-table-card" aria-label="<?php esc_attr_e('Resultados', 'ld-video-auditor'); ?>">
            <div id="ldva-summary" class="ldva-summary"><?php esc_html_e('Seleccione un curso para comenzar.', 'ld-video-auditor'); ?></div>
            <div class="ldva-scroll">
                <table class="widefat ldva-table" id="ldva-table">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Nombre del curso', 'ld-video-auditor'); ?></th>
                            <th><?php esc_html_e('Nombre de la lección', 'ld-video-auditor'); ?></th>
                            <th><?php esc_html_e('Plataforma', 'ld-video-auditor'); ?></th>
                            <th><?php esc_html_e('URL original del video', 'ld-video-auditor'); ?></th>
                            <th><?php esc_html_e('Código HTML embebido', 'ld-video-auditor'); ?></th>
                            <th><?php esc_html_e('Shortcode', 'ld-video-auditor'); ?></th>
                            <th><?php esc_html_e('Estado', 'ld-video-auditor'); ?></th>
                            <th><?php esc_html_e('Acciones', 'ld-video-auditor'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="8" class="ldva-empty">
                                <span class="dashicons dashicons-search" aria-hidden="true"></span>
                                <span><?php esc_html_e('Seleccione un curso para comenzar.', 'ld-video-auditor'); ?></span>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
    </div>

    <div id="ldva-modal" class="ldva-modal" hidden>
        <div class="ldva-modal-backdrop" data-close-modal></div>
        <div class="ldva-modal-dialog" role="dialog" aria-modal="true" aria-labelledby="ldva-modal-title">
            <button type="button" class="ldva-modal-close" data-close-modal aria-label="<?php esc_attr_e('Cerrar', 'ld-video-auditor'); ?>">
                <span class="dashicons dashicons-no-alt" aria-hidden="true"></span>
            </button>
            <div class="ldva-modal-header">
                <h2 id="ldva-modal-title"><?php esc_html_e('Editar video de la lección', 'ld-video-auditor'); ?></h2>
                <p id="ldva-modal-lesson" class="ldva-modal-lesson"></p>
            </div>
            <div class="ldva-modal-body">
                <input type="hidden" id="ldva-edit-lesson-id">
                <div class="ldva-form-group">
                    <label for="ldva-edit-url"><?php esc_html_e('URL del video', 'ld-video-auditor'); ?></label>
                    <input type="url" id="ldva-edit-url" class="large-text" placeholder="https://vimeo.com/…">
                    <p class="description"><?php esc_html_e('YouTube y Vimeo actualizan Video Progression. Una URL de Bunny —incluido dash.bunny.net— genera automáticamente su shortcode.', 'ld-video-auditor'); ?></p>
                </div>
                <div class="ldva-form-group">
                    <label for="ldva-edit-embed"><?php esc_html_e('Código HTML embebido', 'ld-video-auditor'); ?></label>
                    <textarea id="ldva-edit-embed" class="large-text code" rows="6" placeholder="<iframe src=&quot;https://player.vimeo.com/video/…&quot; …></iframe>"></textarea>
                    <p class="description"><?php esc_html_e('El iframe guardado se mostrará al final del contenido de la lección.', 'ld-video-auditor'); ?></p>
                </div>
                <div class="ldva-form-group">
                    <label for="ldva-edit-shortcode"><?php esc_html_e('Shortcode de video', 'ld-video-auditor'); ?></label>
                    <textarea id="ldva-edit-shortcode" class="large-text code" rows="3" placeholder='[video src="https://…"]'></textarea>
                    <p class="description"><?php esc_html_e('Admite shortcodes que contengan o generen videos de YouTube, Vimeo o Bunny Stream. Si lo completas, tendrá prioridad sobre la URL y el iframe.', 'ld-video-auditor'); ?></p>
                </div>
                <div id="ldva-modal-message" class="ldva-modal-message" aria-live="polite"></div>
            </div>
            <div class="ldva-modal-actions">
                <button type="button" class="button" data-close-modal><?php esc_html_e('Cancelar', 'ld-video-auditor'); ?></button>
                <button type="button" class="button button-primary" id="ldva-save-video"><?php esc_html_e('Guardar cambios', 'ld-video-auditor'); ?></button>
            </div>
        </div>
    </div>
</div>
