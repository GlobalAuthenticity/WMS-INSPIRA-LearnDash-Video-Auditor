<?php
/**
 * Se ejecuta al desinstalar el plugin desde el panel de WordPress.
 * Limpia los metadatos que el plugin almacena en las lecciones.
 */
defined('WP_UNINSTALL_PLUGIN') || exit;

global $wpdb;

$meta_keys = ['_ldva_video_url', '_ldva_video_embed', '_ldva_video_shortcode'];
$placeholders = implode(',', array_fill(0, count($meta_keys), '%s'));

$wpdb->query(
    $wpdb->prepare(
        "DELETE FROM {$wpdb->postmeta} WHERE meta_key IN ($placeholders)",
        $meta_keys
    )
);

// Registro de progresión de video Bunny por usuario (_ldva_bunny_watched_{lesson_id}).
$wpdb->query(
    $wpdb->prepare(
        "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE %s",
        $wpdb->esc_like('_ldva_bunny_watched_') . '%'
    )
);

// Claves de "Embed View Token Authentication" configuradas por biblioteca de Bunny.
delete_option('ldva_bunny_tokens');
