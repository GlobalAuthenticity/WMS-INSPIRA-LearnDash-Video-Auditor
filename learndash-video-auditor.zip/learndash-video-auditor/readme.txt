=== LearnDash Video Auditor ===
Contributors: codex
Tags: learndash, video, youtube, vimeo, auditor
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 2.8.2
License: GPLv2 or later

Audita videos de YouTube y Vimeo en las lecciones de LearnDash.

== Description ==

El plugin agrega “LearnDash LMS > Auditor de videos” al panel de administración.
Detecta enlaces directos, iframes, shortcodes que contengan URLs y la configuración
de Video Progression almacenada por LearnDash. Incluye búsqueda, filtros, copiado,
carga AJAX y exportación CSV/XLSX.

== Installation ==

1. Suba el archivo ZIP desde Plugins > Añadir plugin > Subir plugin.
2. Active “LearnDash Video Auditor”.
3. Abra LearnDash LMS > Auditor de videos.

== Changelog ==

= 2.8.2 =
* Corrección crítica: gate_mark_complete() estaba tipado con 4 parámetros
  obligatorios ($process, $post, $user_id, $course_id) para el filtro
  learndash_process_mark_complete. En instalaciones donde LearnDash (sfwd-lms)
  dispara ese filtro con solo 3 argumentos (sin $course_id, según la ruta
  interna de ld-course-progress.php que procese la finalización), PHP 8+
  lanzaba un ArgumentCountError fatal ("Too few arguments to function
  LDVA_Admin::gate_mark_complete(), 3 passed... and exactly 4 expected"),
  rompiendo la página completa justo al hacer clic en "Marcar como
  completado". Se agregó valor por defecto ($course_id = 0), parámetro que
  de todas formas no se usaba dentro del método.

= 2.8.1 =
* Corrección crítica: resign_bunny_embeds() podía provocar un error fatal
  ("Ha habido un error crítico en esta web") en cualquier lección con video
  de Bunny, porque preg_replace_callback() devuelve null cuando el motor de
  PCRE falla (por ejemplo, al superar pcre.backtrack_limit en contenido muy
  grande o denso, como el de una lección con Elementor), y el método estaba
  tipado para devolver siempre string. Ahora, si el refirmado falla, la
  lección se muestra igual (sin refirmar ese video) en vez de romper toda la
  página. Se aplicó el mismo resguardo a replace_video_by_id() y
  remove_video_from_content(), que tenían el mismo patrón de riesgo.

= 2.8.0 =
* Al agregar o editar un video de Bunny Stream desde el modal (por URL o
  pegando su iframe), el plugin ahora SIEMPRE lo guarda como el shortcode
  [bunnycdn_stream_video ...], nunca como un iframe suelto en el contenido
  o en la meta del plugin. Si no logra derivar biblioteca/ID válidos de lo
  que se pegó, muestra un error en vez de guardar un iframe sin firmar como
  respaldo silencioso. Esto garantiza que el token se recalcule en cada
  visita (vía render del shortcode), no solo en el momento de guardar.
* Eliminado el generador de iframe estático para Bunny (bunny_embed_from_url),
  que ya no se usa en ningún flujo.

= 2.7.1 =
* La papelera de cada fila de token de Bunny ahora borra de inmediato en la
  base de datos (con confirmación) en vez de solo quitar la fila de la
  pantalla hasta presionar "Guardar tokens". Una fila recién añadida que aún
  no se ha guardado se sigue quitando localmente sin necesidad de llamar al
  servidor, porque no hay nada que borrar todavía.

= 2.7.0 =
* Corrección importante: el token de Bunny Stream ahora se aplica a
  *cualquier* iframe de Bunny que aparezca en el HTML final de la lección
  (pegado a mano en el contenido, guardado en la meta del plugin o generado
  por el shortcode), no solo al shortcode. Antes, un iframe pegado
  directamente en el contenido —incluidas lecciones creadas antes de esta
  función— nunca se firmaba, y el guardado desde el modal firmaba una sola
  vez al momento de guardar en vez de en cada visita, por lo que el enlace
  terminaba expirando.
* Nota: esta reescritura ocurre sobre el filtro the_content de WordPress. Si
  una lección se arma completamente con el editor de Elementor (contenido en
  _elementor_data en vez de post_content), el iframe puede no pasar por este
  filtro y no firmarse; en ese caso hay que revisarlo aparte.

= 2.6.1 =
* La sección de token de Bunny Stream ahora tiene una casilla "No expira"
  por biblioteca: fija internamente una expiración muy lejana (10 años) en
  vez de un número fijo de segundos, ya que Bunny siempre exige una fecha de
  expiración en el token (no existen tokens sin vencimiento). Como el token
  se recalcula en cada carga de página, en la práctica el video nunca deja
  de reproducir por esta causa.

= 2.6.0 =
* Nueva sección "Autenticación por token (Bunny Stream)" en el Auditor de
  videos: permite guardar, por biblioteca de Bunny, la clave de "Embed View
  Token Authentication". El plugin firma automáticamente (SHA256, token +
  expires) todos los embeds e iframes de Bunny que genera, tanto al guardar
  una URL/video desde el modal como al renderizar el shortcode
  [bunnycdn_stream_video]. Sin una clave configurada para la biblioteca, los
  embeds se generan sin firmar como antes.
* El atributo tokenAuth="false" del shortcode desactiva la firma para ese
  video puntual aunque exista una clave configurada para su biblioteca.
* La desinstalación también elimina las claves de token guardadas.

= 2.5.4 =
* Anillo de foco más suave (halo con box-shadow que respeta el color del
  esquema de admin) en lugar de un outline duro, consistente en botones,
  campos y opciones del menú de Acciones.

= 2.5.3 =
* Redistribución de columnas: menos ancho reservado para Acciones (ahora es
  un solo botón) y más para URL/HTML embebido/Shortcode, que se truncaban
  más de lo necesario.
* Rayado alterno sutil entre filas para facilitar la lectura horizontal en la
  tabla de escritorio, sin afectar la vista de tarjetas en móvil.

= 2.5.2 =
* Corregido: copiar un shortcode o HTML embebido que contuviera comillas
  (p. ej. [bunnycdn_stream_video library="…" id="…"]) copiaba el valor
  cortado, porque la comilla interna rompía el atributo data-value donde se
  guarda el texto a copiar.

= 2.5.1 =
* Corregido el desalineamiento vertical de los iconos dashicons dentro de los
  botones (toolbar, menú de acciones, badges y buscador): ahora cada icono
  centra su propio glyph en la caja en vez de depender de las métricas de la
  fuente.

= 2.5.0 =
* La columna Acciones ahora muestra un solo botón "Acciones" que despliega un
  menú con Ver lección, Añadir/Editar video y Remover video, en vez de varios
  botones apilados. Se cierra al elegir una opción, al hacer clic fuera o con
  la tecla Escape.

= 2.4.4 =
* Columnas de la tabla con ancho proporcional (table-layout fijo) en lugar de
  un ancho mínimo forzado: el contenido largo (URL, HTML embebido, shortcode)
  ahora se trunca dentro de su celda y ya no aparece scroll horizontal en
  pantallas de escritorio normales.

= 2.4.3 =
* La pantalla ahora ocupa el ancho completo del área de contenido del admin
  en lugar de quedar limitada a 1400px con espacio vacío a la derecha.

= 2.4.2 =
* La pantalla del Auditor de videos ahora oculta los avisos de otros plugins
  (banners de actualización, notices de terceros) para mantenerla limpia. No
  afecta a ninguna otra pantalla del admin.

= 2.4.1 =
* Rediseño completo de la interfaz de administración: sistema de tokens de
  diseño, tipografía y espaciado consistentes, iconografía con dashicons.
* Mejores estados visuales (hover, focus, disabled, carga y vacío) y contraste
  accesible en insignias de plataforma/estado.
* Responsive revisado para escritorio, tablet y móvil sin cambios de
  funcionalidad ni de los selectores usados por el JavaScript.
* Aviso de progresión Bunny en el frontend con estilo más claro y coherente.

= 2.4.0 =
* Validación server-side de la progresión de videos Bunny: "Marcar completado" se
  bloquea en el servidor (filtro learndash_process_mark_complete) hasta ver todos
  los videos, sin poder eludirse desde el navegador.
* El avance se registra por usuario y lección mediante un endpoint AJAX con nonce,
  validando que la clave del video pertenezca realmente a la lección.
* Los administradores omiten la barrera; se puede desactivar con el filtro
  ldva_enforce_bunny_progression.

= 2.3.1 =
* Protección contra inyección de fórmulas (CSV/Excel) en la exportación CSV.
* Cadenas de la tabla y del resumen ahora son traducibles.
* Aviso de progresión muestra confirmación al completar todos los videos Bunny.
* Limpieza de metadatos de video al desinstalar el plugin (uninstall.php).

= 2.3.0 =
* Generación automática de shortcode desde URLs del panel, reproductor o iframe Bunny.
* Implementación de respaldo para reproducir el shortcode bunnycdn_stream_video.

= 2.2.0 =
* Campo para guardar y procesar shortcodes de video.
* Columna de shortcode con copiado y exportación.

= 2.1.2 =
* Aviso compacto debajo del video mientras la lección espera su finalización.
* El aviso desaparece automáticamente al terminar todos los videos Bunny.

= 2.1.1 =
* La eliminación limpia también referencias almacenadas en metadatos adicionales o serializados.

= 2.1.0 =
* Botón para remover un video y todas sus referencias de la lección.
* Exclusión de scripts y enlaces auxiliares de Vimeo que no representan videos.

= 2.0.0 =
* Reporte Excel global con todos los cursos y únicamente sus lecciones con video.
* Columnas simplificadas: curso, lección, plataforma y enlace del video.

= 1.9.0 =
* Integración con el evento de finalización del reproductor Bunny Stream.
* Bloqueo de “Marcar completado” hasta finalizar todos los videos Bunny de la lección.
* Conservación local del estado de visualización tras recargar la página.

= 1.8.0 =
* Las URLs del reproductor Bunny Stream generan automáticamente un iframe responsivo.
* Los enlaces Bunny pueden añadirse sin pegar manualmente el código HTML.

= 1.7.0 =
* Compatibilidad con embeds nuevos y heredados de Bunny Stream.
* Detección, edición, filtrado y deduplicación por biblioteca e ID de Bunny.

= 1.6.0 =
* Reemplazo de videos por su ID aunque el iframe original tenga atributos o entidades diferentes.
* Deduplicación adicional en la interfaz para URL directa e iframe del mismo video.

= 1.5.0 =
* Agrupa la URL directa y el iframe cuando pertenecen al mismo ID de YouTube o Vimeo.
* Conserva la URL original y el código embebido dentro de una única fila.

= 1.4.0 =
* La edición reemplaza la referencia original en contenido o Video Progression cuando es identificable.
* Evita crear un registro adicional al modificar un video existente.

= 1.3.0 =
* Tabla, filtros, acciones y modal adaptados para celulares y tabletas.
* Iframes administrados con ancho fluido y proporción 16:9.

= 1.2.0 =
* Botón para abrir cada lección desde la columna Acciones.
* Mejora en la visualización de caracteres especiales en los títulos.

= 1.1.0 =
* Edición AJAX de la URL de Video Progression y de un iframe administrado por el plugin.
* Botones para añadir o editar videos directamente desde la tabla.

= 1.0.0 =
* Primera versión.
